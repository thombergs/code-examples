package com.reflectoring.annotation.processor;

import com.google.auto.service.AutoService;
import com.squareup.javapoet.*;
import org.apache.commons.text.CaseUtils;

import javax.annotation.processing.*;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;
import javax.tools.Diagnostic;
import javax.tools.JavaFileObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@SupportedAnnotationTypes("com.reflectoring.annotation.processor.Builder")
@SupportedSourceVersion(SourceVersion.RELEASE_11)
@AutoService(Processor.class)
public class BuilderProcessor extends AbstractProcessor {

    private Filer filer;
    private Messager messager;
    private Elements elementUtils;
    private Types typeUtils;

    @Override
    public synchronized void init(ProcessingEnvironment processingEnv) {

        super.init(processingEnv);
        filer = processingEnv.getFiler();
        messager = processingEnv.getMessager();
        elementUtils = processingEnv.getElementUtils();
        typeUtils = processingEnv.getTypeUtils();
    }

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {

        for (Element typeElement : roundEnv.getElementsAnnotatedWith(Builder.class)) {

            List<Element> fieldElements = typeElement.getEnclosedElements().stream().filter(e -> ElementKind.FIELD.equals(e.getKind())).collect(
                    Collectors.toList());

            String packageName = elementUtils.getPackageOf(typeElement).getQualifiedName().toString();
            String variableName = CaseUtils.toCamelCase(typeElement.getSimpleName().toString(), false, '_');
            typeElement.getSimpleName().toString();
            System.out.println("Class is: " + typeElement.getSimpleName());
            System.out.println("Package name is: " + packageName);

            String builderName = String.format("%sBuilder", typeElement.getSimpleName().toString());
            ClassName builderType = ClassName.get(packageName, builderName);

            List<FieldSpec> fields = new ArrayList<FieldSpec>(fieldElements.size());
            List<MethodSpec> fieldSetters = new ArrayList<MethodSpec>(fieldElements.size());

            for (Element fieldElement : fieldElements) {

                TypeName typeName = TypeName.get(fieldElement.asType());
                System.out.println("TypeName is: " + typeName);

                String fieldName = getBaseName(fieldElement.getSimpleName().toString());
                System.out.println("Field Name is: " + fieldName);

                fields.add(FieldSpec.builder(typeName, fieldName, Modifier.PRIVATE).build());

                fieldSetters.add(
                        MethodSpec.methodBuilder(fieldName).addModifiers(Modifier.PUBLIC).returns(builderType).addParameter(typeName, fieldName).addStatement(
                                "this.$N = $N", fieldName, fieldName).addStatement("return this").build());
            }

            TypeName targetType = TypeName.get(typeElement.asType());
            MethodSpec.Builder buildMethodBuilder = MethodSpec.methodBuilder("build").addModifiers(Modifier.PUBLIC).returns(targetType).addStatement(
                    "$1T $2N = new $1T()", targetType, variableName);

            for (FieldSpec field : fields) {

                buildMethodBuilder.addStatement("$1N.set$2N(this.$3N)", variableName, CaseUtils.toCamelCase(field.name, true, '_'), field.name);
            }

            buildMethodBuilder.addStatement("return $N", variableName);
            MethodSpec buildMethod = buildMethodBuilder.build();

            TypeSpec builder = TypeSpec.classBuilder(builderType).addModifiers(Modifier.PUBLIC, Modifier.FINAL).addFields(fields).addMethods(
                    fieldSetters).addMethod(buildMethod).build();

            JavaFile file = JavaFile.builder(builderType.packageName(), builder.toBuilder().build()).build();

            try {

                file.writeTo(filer);
            } catch (IOException ex) {
                messager.printMessage(Diagnostic.Kind.ERROR, "Failed to write file for element", typeElement);
            }

        }

        return true;
    }

    private String getBaseName(String name) {

        int lastPeriodIndex = name.lastIndexOf('.');
        if (lastPeriodIndex > 0) {
            name = name.substring(0, lastPeriodIndex);
        }

        return name;
    }
}